<?php
$less_variables = array(
	'color'        => '#5f87d1',
	'a-color'      => 'desaturate(darken(@color, 20%),4%)',
	'body-color'   => '#444',
	'border-color' => '#cecece',
	'cart-url'     => "'../assets/img/blue'",
);


