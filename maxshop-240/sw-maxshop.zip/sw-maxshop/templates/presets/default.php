<?php
$less_variables = array(
	'color'        => '#ea3a3c',
	'a-color'      => '#ea3a3c',
	'body-color'   => '#444',
	'border-color' => '#cecece',
	'cart-url'     => "'../assets/img/default'",
);

