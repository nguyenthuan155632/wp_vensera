<?php
$less_variables = array(
	'color'        => '#20bc5a',
	'a-color'      => 'desaturate(darken(@color, 20%),4%)',
	'body-color'   => '#444',
	'border-color' => '#cecece',
	'cart-url'     => "'../assets/img/green'",
);

