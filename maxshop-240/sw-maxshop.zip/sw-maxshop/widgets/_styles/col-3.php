<?php

$ws['col-3'] = array(
		'before_title' => '<div class="button-ver-menu">',
		'after_title' => '</div>',
		'before_widget' => '<div class="col-lg-3 col-md-3  col-sm-6 widget %1$s %2$s" data-scroll-reveal="enter right move 20px wait 0.3s"><div class="widget-inner">',
		'after_widget' => '</div></div>',
	);